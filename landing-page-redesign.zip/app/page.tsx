'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import {
  Shield,
  Github,
  Zap,
  Lock,
  GitBranch,
  BarChart3,
  Users,
  CheckCircle,
  ArrowRight,
  Menu,
  X,
  Docker,
  Server,
  Cpu,
  AlertCircle,
  ChevronDown,
} from 'lucide-react'

export default function LandingPage() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [activeFaq, setActiveFaq] = useState<number | null>(null)

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.8, ease: 'easeOut' },
    },
  }

  const features = [
    {
      icon: <Zap className="w-6 h-6" />,
      title: 'One-Click Deployments',
      desc: 'Push to GitHub, auto-deploy with zero config. A webhook triggers the full pipeline.',
    },
    {
      icon: <GitBranch className="w-6 h-6" />,
      title: 'GitHub Integration',
      desc: 'Seamless GitHub webhooks for automatic deployments on every push.',
    },
    {
      icon: <Docker className="w-6 h-6" />,
      title: 'Automatic Docker Builds',
      desc: 'Containerize your apps automatically with optimized Docker images.',
    },
    {
      icon: <AlertCircle className="w-6 h-6" />,
      title: 'Health Checks',
      desc: 'Monitor app health with configurable health check endpoints.',
    },
    {
      icon: <Zap className="w-6 h-6" />,
      title: 'Zero Downtime Rollbacks',
      desc: 'Deploy went wrong? Roll back to any previous deployment in one click.',
    },
    {
      icon: <BarChart3 className="w-6 h-6" />,
      title: 'Real-Time Metrics',
      desc: 'Live container metrics, deployment history, and health monitoring.',
    },
    {
      icon: <Lock className="w-6 h-6" />,
      title: 'SSL Automation',
      desc: 'Every app gets auto-provisioned Let\'s Encrypt SSL certificates.',
    },
    {
      icon: <Users className="w-6 h-6" />,
      title: 'Teams & Access Control',
      desc: 'Collaborate with team members with fine-grained access controls.',
    },
  ]

  const workflowSteps = [
    'Git Push',
    'Webhook',
    'Build',
    'Docker Image',
    'Deploy',
    'Health Check',
    'Traffic Switch',
    'Monitoring',
  ]

  const technologies = [
    'Docker',
    'GitHub',
    'Node.js',
    'PostgreSQL',
    'Redis',
    'Nginx',
    'AWS',
    'Kubernetes',
  ]

  const stats = [
    { value: '99.99%', label: 'Deployment Success' },
    { value: '<2s', label: 'Rollback Time' },
    { value: '24/7', label: 'Health Monitoring' },
    { value: '100%', label: 'Self-Hosted' },
  ]

  const faqs = [
    {
      question: 'How does the deployment process work?',
      answer:
        'Connect your GitHub repository, and Sentinel automatically builds, tests, and deploys your application whenever you push code. Our system handles Docker containerization, health checks, and traffic routing.',
    },
    {
      question: 'Can I self-host Sentinel?',
      answer:
        'Yes! Sentinel is fully open-source and can be self-hosted on your own infrastructure. Deploy it on any server with Docker support.',
    },
    {
      question: 'Does Sentinel support Docker?',
      answer:
        'Absolutely. Sentinel uses Docker for all containerized deployments, ensuring consistent environments from development to production.',
    },
    {
      question: 'How does rollback work?',
      answer:
        'Rollback is instantaneous. We maintain all previous deployments and can switch traffic back to any previous version in under 2 seconds with zero downtime.',
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-white overflow-hidden">
      {/* Animated Background */}
      <div className="fixed inset-0 -z-10 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/10 via-transparent to-blue-500/10" />
        <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl" />
        <svg className="absolute inset-0 w-full h-full opacity-5" preserveAspectRatio="none">
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>

      {/* Navbar */}
      <nav className="sticky top-0 z-40 backdrop-blur-md bg-slate-950/50 border-b border-cyan-500/10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-gradient-to-br from-cyan-400 to-blue-500 rounded-lg">
                <Shield className="w-5 h-5 text-slate-950" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
                Sentinel
              </span>
            </div>

            {/* Desktop Menu */}
            <div className="hidden md:flex items-center gap-8">
              {['Features', 'Architecture', 'Pricing', 'Docs'].map(item => (
                <a
                  key={item}
                  href="#"
                  className="text-slate-300 hover:text-cyan-400 transition-colors text-sm"
                >
                  {item}
                </a>
              ))}
            </div>

            <div className="flex items-center gap-3">
              <a
                href="https://github.com"
                className="hidden sm:flex items-center gap-2 px-4 py-2 text-slate-300 hover:text-cyan-400 transition-colors"
              >
                <Github className="w-4 h-4" />
              </a>
              <button className="px-4 py-2 bg-gradient-to-r from-cyan-400 to-blue-500 text-slate-950 font-semibold rounded-lg hover:shadow-lg hover:shadow-cyan-400/50 transition-all">
                Get Started
              </button>
              <button
                className="md:hidden p-2 text-slate-300"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                {mobileMenuOpen ? (
                  <X className="w-6 h-6" />
                ) : (
                  <Menu className="w-6 h-6" />
                )}
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-20 pb-32 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
          >
            <div className="inline-block mb-6 px-4 py-2 bg-cyan-500/10 border border-cyan-500/30 rounded-full">
              <span className="text-cyan-400 text-sm font-medium">
                Open-Source Deployment Platform
              </span>
            </div>

            <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
              Deploy.{' '}
              <span className="bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-400 bg-clip-text text-transparent">
                Monitor.
              </span>
              {' '}Recover.
            </h1>

            <p className="text-xl text-slate-400 mb-8 max-w-2xl mx-auto leading-relaxed">
              Sentinel is an intelligent self-hosted deployment platform that automatically builds,
              deploys, monitors, heals, and rolls back your applications with zero downtime.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="px-8 py-3 bg-gradient-to-r from-cyan-400 to-blue-500 text-slate-950 font-semibold rounded-lg hover:shadow-lg hover:shadow-cyan-400/50 transition-all flex items-center justify-center gap-2">
                Start Deploying
                <ArrowRight className="w-4 h-4" />
              </button>
              <a
                href="https://github.com"
                className="px-8 py-3 border border-slate-600 text-slate-300 font-semibold rounded-lg hover:border-cyan-400 hover:text-cyan-400 transition-all flex items-center justify-center gap-2"
              >
                <Github className="w-4 h-4" />
                View on GitHub
              </a>
            </div>
          </motion.div>

          {/* Dashboard Preview */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="mt-16 rounded-xl border border-cyan-500/20 bg-gradient-to-b from-slate-800/50 to-slate-900/50 p-6 backdrop-blur-sm"
          >
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: 'Status', value: '✓ Healthy', color: 'text-green-400' },
                { label: 'Deployments', value: '24', color: 'text-cyan-400' },
                { label: 'CPU', value: '34%', color: 'text-blue-400' },
                { label: 'Memory', value: '2.1 GB', color: 'text-purple-400' },
              ].map((stat, i) => (
                <div key={i} className="bg-slate-800/50 rounded-lg p-4 border border-slate-700/50">
                  <div className="text-xs text-slate-400 mb-2">{stat.label}</div>
                  <div className={`text-2xl font-bold ${stat.color}`}>{stat.value}</div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-16 px-4 border-t border-slate-800">
        <div className="max-w-6xl mx-auto">
          <h3 className="text-center text-slate-400 text-sm font-medium mb-8">
            Built with technologies developers love
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4">
            {technologies.map((tech, i) => (
              <motion.div
                key={tech}
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ delay: i * 0.05 }}
                className="p-4 rounded-lg bg-slate-800/30 border border-slate-700/50 text-center text-slate-300 hover:border-cyan-500/50 transition-colors"
              >
                {tech}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold mb-4">Why developers love Sentinel</h2>
            <p className="text-slate-400 max-w-2xl mx-auto">
              Everything you need to ship production-ready applications with confidence.
            </p>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            className="grid md:grid-cols-2 lg:grid-cols-4 gap-6"
          >
            {features.map((feature, i) => (
              <motion.div
                key={i}
                variants={itemVariants}
                className="p-6 rounded-xl border border-slate-700/50 bg-slate-800/30 hover:border-cyan-500/50 hover:bg-slate-800/50 transition-all group cursor-default"
              >
                <div className="text-cyan-400 mb-3 group-hover:scale-110 transition-transform">
                  {feature.icon}
                </div>
                <h3 className="font-semibold mb-2">{feature.title}</h3>
                <p className="text-slate-400 text-sm">{feature.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Workflow Section */}
      <section className="py-20 px-4 border-t border-slate-800">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold mb-4">How it works</h2>
            <p className="text-slate-400">Fully automated deployment pipeline from push to production</p>
          </motion.div>

          <div className="flex overflow-x-auto md:overflow-visible gap-4 pb-4 md:pb-0">
            {workflowSteps.map((step, i) => (
              <div key={i} className="flex items-center gap-4 flex-shrink-0 md:flex-shrink">
                <div className="flex flex-col items-center">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center text-slate-950 font-bold text-sm">
                    {i + 1}
                  </div>
                  <p className="text-slate-400 text-sm mt-2 text-center whitespace-nowrap">{step}</p>
                </div>
                {i < workflowSteps.length - 1 && (
                  <ArrowRight className="w-5 h-5 text-slate-600 flex-shrink-0" />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-slate-800/30 to-transparent">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            {stats.map((stat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="text-center"
              >
                <div className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent mb-2">
                  {stat.value}
                </div>
                <p className="text-slate-400">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 px-4 border-t border-slate-800">
        <div className="max-w-3xl mx-auto">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            className="text-center mb-12"
          >
            <h2 className="text-4xl font-bold mb-4">Frequently asked questions</h2>
            <p className="text-slate-400">Everything you need to know about Sentinel</p>
          </motion.div>

          <div className="space-y-4">
            {faqs.map((faq, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className="border border-slate-700/50 rounded-lg overflow-hidden"
              >
                <button
                  onClick={() => setActiveFaq(activeFaq === i ? null : i)}
                  className="w-full px-6 py-4 bg-slate-800/30 hover:bg-slate-800/50 flex items-center justify-between transition-colors"
                >
                  <span className="font-semibold text-left">{faq.question}</span>
                  <ChevronDown
                    className={`w-5 h-5 transition-transform ${
                      activeFaq === i ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                {activeFaq === i && (
                  <div className="px-6 py-4 bg-slate-900/50 border-t border-slate-700/50 text-slate-400">
                    {faq.answer}
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 border-t border-slate-800">
        <div className="max-w-2xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="p-12 rounded-xl border border-cyan-500/20 bg-gradient-to-br from-slate-800/50 to-slate-900/50"
          >
            <h2 className="text-3xl font-bold mb-4">Ready to deploy with confidence?</h2>
            <p className="text-slate-400 mb-8">
              Connect your GitHub account and deploy your first app in under a minute.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="px-8 py-3 bg-gradient-to-r from-cyan-400 to-blue-500 text-slate-950 font-semibold rounded-lg hover:shadow-lg hover:shadow-cyan-400/50 transition-all">
                Deploy Now
              </button>
              <a
                href="https://github.com"
                className="px-8 py-3 border border-slate-600 text-slate-300 font-semibold rounded-lg hover:border-cyan-400 hover:text-cyan-400 transition-all"
              >
                GitHub
              </a>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-800 py-8 px-4">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4 text-slate-400 text-sm">
          <div>Sentinel — Open-source deployment platform</div>
          <div className="flex gap-6">
            <a href="#" className="hover:text-cyan-400 transition-colors">
              Documentation
            </a>
            <a href="#" className="hover:text-cyan-400 transition-colors">
              GitHub
            </a>
            <a href="#" className="hover:text-cyan-400 transition-colors">
              License
            </a>
          </div>
          <div>Made with ❤️ for developers</div>
        </div>
      </footer>
    </div>
  )
}
